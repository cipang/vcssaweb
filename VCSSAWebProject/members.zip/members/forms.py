from django import forms
from django.db import models
from modelcluster.fields import ParentalKey
from wagtail.admin.edit_handlers import (
    FieldPanel, FieldRowPanel,
    InlinePanel, MultiFieldPanel
)
from wagtail.core.fields import RichTextField
from wagtail.contrib.forms.models import AbstractFormField, AbstractForm
from wagtail.users.forms import UserCreationForm
from users.models import User, Subunions


class SignUpPage(UserCreationForm):

    def __init__(self, *args, **kwargs):
        super(SignUpPage, self).__init__(*args, **kwargs)
        for fields in self.Meta.exclude:
            if fields in self.fields:
                del self.fields[fields]

    subunions = forms.ModelMultipleChoiceField(queryset=Subunions.objects.all(), required=True, widget=forms.CheckboxSelectMultiple)

    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'password1', 'password2', 'subunions',)
        exclude = ('is_superuser',)


# class PassWordResetForm():
#     pass