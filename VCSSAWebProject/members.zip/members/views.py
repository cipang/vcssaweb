from django.conf import settings
from django.contrib.auth import get_user_model, update_session_auth_hash, authenticate, login
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import EmailMessage
from django.db.models import Q
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render, render_to_response
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.translation import ugettext as _
from django.views.decorators.vary import vary_on_headers

from wagtail.admin import messages
from wagtail.admin.forms.search import SearchForm
from wagtail.admin.utils import any_permission_required, permission_denied, permission_required
from wagtail.core import hooks
from wagtail.core.compat import AUTH_USER_APP_LABEL, AUTH_USER_MODEL_NAME
from wagtail.users.forms import UserCreationForm, UserEditForm
from wagtail.users.utils import user_can_delete_user
from wagtail.utils.loading import get_custom_form
from wagtail.utils.pagination import paginate

from django.contrib.auth.models import Group
from itertools import chain


from members.tokens import account_activation_token
from .forms import SignUpPage

COMMON_MAILS = {'gmail.com': 'https://mail.google.com/',
                'hotmail.com': 'https://outlook.live.com/',
                'outlook.com': 'https://outlook.live.com/',
                'live.com': 'https://outlook.live.com/',
                'msn.com': 'https://outlook.live.com/',
                'yahoo.com': 'https://mail.yahoo.com/',
                'qq.com': 'https://mail.qq.com/',
                '163.com': 'https://mail.163.com/',
                '126.com': 'https://www.126.com/',
                'sina.': 'https://mail.sina.com.cn/',
                'sohu.com': 'https://mail.sohu.com/',
                }


User = get_user_model()


# Typically we would check the permission 'auth.change_user' (and 'auth.add_user' /
# 'auth.delete_user') for user management actions, but this may vary according to
# the AUTH_USER_MODEL setting
add_user_perm = "{0}.add_{1}".format(AUTH_USER_APP_LABEL, AUTH_USER_MODEL_NAME.lower())
change_user_perm = "{0}.change_{1}".format(AUTH_USER_APP_LABEL, AUTH_USER_MODEL_NAME.lower())
delete_user_perm = "{0}.delete_{1}".format(AUTH_USER_APP_LABEL, AUTH_USER_MODEL_NAME.lower())


# @permission_required(add_user_perm)
def create(request):
    """Return context to create.html"""

    for fn in hooks.get_hooks('before_create_user'):
        result = fn(request)
        if hasattr(result, 'status_code'):
            return result

    if request.method == 'POST':
        form = SignUpPage(request.POST)
        # form = get_user_creation_form()(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            success_text = "Congratulations " + user.username + "! You are our members now! "
            messages.success(request, success_text)

            # messages.success(request, _("User '{0}' created.").format(user), buttons=[
            # messages.button(reverse('wagtailusers_users:edit', args=(user.pk,)), _('Edit'))
            # ])

            for fn in hooks.get_hooks('after_create_user'):
                result = fn(request, user)
                if hasattr(result, 'status_code'):
                    return result

            # raw_password = form.cleaned_data.get('password1')
            # user = authenticate(username=user.username, password=raw_password)
            # login(request, user)
            return redirect('account_home')
        else:
            messages.error(request, _("The user could not be created due to errors."))
    else:
        form = SignUpPage()

    return render(request, 'sign_up.html', {
        'form': form,
    })


def signup(request):
    if request.method == 'POST':
        form = SignUpPage(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.save()
            to_email = form.cleaned_data.get('email')
            current_site = get_current_site(request)
            # Configuring confirmation email contents
            mail_subject = 'Activate your VCSSA account.'
            message = render_to_string('account_activation_email.html', {
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)).decode(),
                'token': account_activation_token.make_token(user),
            })
            email = EmailMessage(
                mail_subject, message, to=[to_email]
            )
            email.send()
            host_link = None  # link to user's mailbox
            prefix, suffix = to_email.split("@")
            for mail in COMMON_MAILS:
                if suffix in mail:
                    host_link = COMMON_MAILS[mail]
            request.session['message'] = message
            request.session['to_email'] = to_email
            request.session['host_link'] = host_link

            return render(request, 'activate_account_popup.html', {'host_link': host_link})
    else:
        form = SignUpPage()
        return render(request, 'sign_up.html', {'form': form})


def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
        # request.session['user'] = user
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        return redirect('account_home')
    else:  # if token expires
        to_email = request.session.get('to_email')
        return render(request, 'reactivate.html', {'user': user, 'to_email': to_email})


def resend(request):
    message = request.session.get('message')
    to_email = request.session.get('to_email')
    host_link = request.session.get('host_link')

    mail_subject = 'Activate your VCSSA account.'
    if message and to_email is not None:
        print("resending email")
        email = EmailMessage(
            mail_subject, message, to=[to_email]
        )
        email.send()
        messages.success(request, "Email Resent Successfully")
    # reload session
    request.session['message'] = message
    request.session['host_link'] = host_link
    return render(request, 'activate_account_popup.html', {'host_link': host_link})


def reactivate(request, user, to_email):
    if user is not None:  # user info still in db
        domain = get_current_site(request).domain
        mail_subject = 'Rectivate your VCSSA account.'
        message = render_to_string('account_activation_email.html', {
            'user': user,
            'domain': domain,
            'uid': urlsafe_base64_encode(force_bytes(user.pk)).decode(),
            'token': account_activation_token.make_token(user),
        })
        email = EmailMessage(
            mail_subject, message, to=[to_email]
        )
        email.send()
        host_link = None  # link to user's mailbox
        prefix, suffix = to_email.split("@")
        for mail in COMMON_MAILS:
            if suffix in mail:
                host_link = COMMON_MAILS[mail]
        request.session['message'] = message
        request.session['to_email'] = to_email
        request.session['host_link'] = host_link
        return render(request, 'activate_account_popup.html', {'host_link': host_link})
    else:  # user info expired
        messages.error(request, 'Sorry, your registration has expired. Please register again.')
        return redirect('signup')


def accounthome(request):
    return render_to_response('account_home.html')






